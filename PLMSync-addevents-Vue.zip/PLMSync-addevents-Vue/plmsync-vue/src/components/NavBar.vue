<template>
    <div class="nav-main">
      <div class="nav-logo">
        <img src="@/assets/Logo.png" alt="Logo" />
      </div>
      <div class="nav-menu">
        <nav>
          <ul>
            <router-link to="/userlogin/diary">
              <li><a href="#">Home</a></li>
            </router-link>
            <router-link to="/">
              <li><a href="#">Schedule</a></li>
            </router-link>
            <li><a href="#">Status</a></li>
          </ul>
        </nav>
      </div>
      <div class="userProfile">
        <img src="@/assets/user.png" class="avatar" />
       <router-link to="/">
          <div class="signout"></div>
        </router-link>
      </div>
    </div>
  </template>
  
  
  <style scoped>
 .nav-main{
    display: flex;
    justify-content: space-between;
    background-color: #8040B8;
    width: 100%;
    height: 0%;
   }

   .nav-logo{
    display: flex;
    align-items: center;
    justify-content: center;
   }

  .nav-logo>img{
    width: 80%;
    height: 70%;
  }

  .nav-menu{
    display: flex;
  }

  nav{
    display: flex;
    align-items: center;
    justify-content: flex-start; 
  }

  nav ul {
    display: flex;
    list-style-type: none;
    padding: 0;
    display: flex;
    justify-content: space-evenly;
    align-items: center;
  }
  
  nav ul li {
    justify-content: flex-start;
    margin-right: 50px;
    white-space: nowrap;
  }
  
  nav ul li a {
    text-decoration: none;
    color: #ffffff;
    font-weight: bold;
    font-family: sans-serif;
    font-size: 18px;
    
  }

  .userProfile{
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right:10px;
  }

  .avatar {
  width: 30px; 
  height: 30px; 
  border-radius: 50%;
}


  </style>
  
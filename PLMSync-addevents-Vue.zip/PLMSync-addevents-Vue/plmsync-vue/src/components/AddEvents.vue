<template>
    <div>
    <div class="add-event-main">
      <div class="add-event-title">
        <h2>Add Blocked Dates/Events</h2>
      </div>
      <div class="add-event-wrapper">
        <div class="add-event-options">
          <div class="date-select">
            <label>Start-Date</label>
            <input type="date" v-model="formState.startdate" />
            <label>End-Date</label>
            <input type="date" v-model="formState.enddate" />
          </div>

          <div class="time-select">
            <label>Time</label>
            <select v-model="formState.startime">
              <option v-for="option in startTimeMenu" :key="option" :value="option">{{ option }}</option>
            </select>
            <label>to</label>
            <select v-model="formState.endtime">
              <option v-for="option in endTimeMenu" :key="option" :value="option">{{ option }}</option>
            </select>
          </div>

          <div class="event-type-select">
            <label>Event Type</label>
            <select v-model="formState.eventype">
              <option v-for="option in eventTypeMenu" :key="option" :value="option">{{ option }}</option>
            </select>
          </div>

          <div class="details-select">
            <label>Details</label>
            <input type="text" v-model="formState.eventdetails" />
          </div>

          <div class="add-event-button">
            <button @click="handleSubmit">Submit</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      formState: {
        startdate: "",
        enddate: "",
        startime: "",
        endtime: "",
        eventype: "",
        eventdetails: "",
      },
      startTimeMenu: ['09:30', '11:15', '14:00', '15:45', '17:30', '19:15'],
      endTimeMenu: ['11:00', '12:45', '15:30', '17:15', '19:00', '20:45'],
      eventTypeMenu: ['Public Holiday', 'Campus event', 'Semester Break'],
    };
  },
  methods: {
    handleChange(e) {
      this.formState = { ...this.formState, [e.target.name]: e.target.value };
    },
    handleSubmit() {
      this.$emit('submit', this.formState);
    },
  },
}
</script>

<style scoped>
.add-event-main{
    display: grid;
}

.add-event-title{
    color: rgb(40, 2, 52);
    margin-left: 20px;
    margin-bottom: 0px;
}

.add-event-options{
    display: flex; 
    justify-content: space-evenly;
    margin: 5px;
    padding: 5px;
}

.add-event-wrapper{
    border-radius: 10px;
    border: 1rem black;
    background-color: rgb(235, 230, 237);
    box-shadow: 0px 10px 10px #ccc;
    margin: 15px;
}


.add-date-time{
    display: flex;
    justify-content: space-evenly;
}

.add-type-details{
    display: flex;
    justify-content: space-evenly;
}

.date-select>input{
    width: 100%;
    height: 50%;
    border-radius: 5px;
    align-self: center;
    margin: 10px;
}

.menu{
    background-color: white;
    border-radius: 10px;
}

.date-select{
    display: flex; 
}


.date-select> p{
    font-size: small;
}

.time-select{
    display: flex;
    align-items: center; 
}

.time-select>p{
    font-size: small;
}

.time-select> Select{
    width: 70%;
    margin: 10px;
}

.details-select{
    display: flex;  
    align-items: center;
}
.details-select>p{
    font-size: small;
}
.details-select>input{
    width: 100%;
    height: 50%;
}
.details-select>input{
    width: 100%;
    height: 50%;
    border-radius: 5px;
    align-self: center;
    margin: 10px;
}

.event-type-select{
    display: flex;
    align-items: center;
}
.event-type-select>p{
    font-size: small;
}

.event-type-select>Select{
    margin: 10px;
}
#label{
    font-size: small;
    align-self: center;
}

.add-event-button{
    display: flex;
    align-items: center;
    justify-content: center;
}

.add-event-button button {
    width: 100%;
    height: 60%;
    background-color: #8040B8;
    color: white;
    border-radius: 5px;
    padding: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: small;
}
</style>
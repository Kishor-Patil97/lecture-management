<template>
    <div class="table-wrapper">
      <table class="events-table">
        <thead>
          <tr>
            <th>Start date</th>
            <th>End date</th>
            <th>Start time</th>
            <th>End time</th>
            <th>Event type</th>
            <th>Event details</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>2023-12-25</td>
            <td>2023-12-25</td>
            <td>09:30</td>
            <td>17:15</td>
            <td>Public Holiday</td>
            <td>Christmas</td>
            <td>
              <span class="actions">
                <button class="delete-btn" @click="deleteRow(index, row._id)">Delete</button>
              </span>
            </td>
          </tr>
          <tr>
            <td>2023-12-28</td>
            <td>2023-12-28</td>
            <td>17:30</td>
            <td>20:45</td>
            <td>Campus event</td>
            <td>Party</td>
            <td>
              <span class="actions">
                <button class="delete-btn" @click="deleteRow(index, row._id)">Delete</button>
              </span>
            </td>
          </tr>
          <tr>
            <td>2023-12-31</td>
            <td>2023-12-31</td>
            <td>17:30</td>
            <td>20:45</td>
            <td>Campus event</td>
            <td>New year Eve</td>
            <td>
              <span class="actions">
                <button class="delete-btn" @click="deleteRow(index, row._id)">Delete</button>
              </span>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </template>
  
  <script>
  export default {
    props: {
      rows: Array, 
    },
    methods: {
      deleteRow(index, id) {
        console.log(`Deleting row at index ${index} with ID ${id}`);
      },
    },
  };
  </script>
  
  <style scoped>
  .table-wrapper {
    width: 95%;
    margin-left: 30px;
  }
  
  .events-table {
    box-shadow: 0px 10px 10px #ccc;
    border-radius: 10px;
    white-space: nowrap;
    width: 100%;
    margin: auto;
    overflow-x: auto;
  }
  
  .events-table thead {
    color: #222;
  }

  .events-table> thead> tr{
    background-color:  rgb(222, 211, 234);
    
  }
  
  .events-table th,
  .events-table td {
    padding: 0.4rem;
    
  }
  
  .events-table td {
    border-top: 0.5px solid #ddd;
    overflow: hidden;
    text-overflow: ellipsis;

  }
  
  .events-table tbody tr:hover {
    background-color: #eee;
  }
  </style>
  
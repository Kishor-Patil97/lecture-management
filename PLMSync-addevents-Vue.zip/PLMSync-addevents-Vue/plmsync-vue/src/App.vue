<template>
  <NavBar/>
  <AddEvents />
  <EventTable/>
</template>

<script>
import AddEvents from './components/AddEvents.vue';
import NavBar from './components/NavBar.vue';
import EventTable from './components/EventTable.vue';

export default {
  name: 'App',
  components: {
    AddEvents,
    NavBar,
    EventTable,
}
}
</script>

<style>
.table-wrapper {
    width: 95%;
    margin-left: 30px;
  }
  
  .events-table {
    box-shadow: 0px 10px 10px #ccc;
    border-radius: 10px;
    white-space: nowrap;
    width: 100%;
    margin: auto;
    overflow-x: auto;
  }
  
  .events-table thead {
    color: #222;
  }

  .events-table> thead> tr{
    background-color:  rgb(222, 211, 234);
    
  }
  
  .events-table th,
  .events-table td {
    padding: 0.4rem;
    
  }
  
  .events-table td {
    border-top: 0.5px solid #ddd;
    overflow: hidden;
    text-overflow: ellipsis;

  }
  
  .events-table tbody tr:hover {
    background-color: #eee;
  }
</style>